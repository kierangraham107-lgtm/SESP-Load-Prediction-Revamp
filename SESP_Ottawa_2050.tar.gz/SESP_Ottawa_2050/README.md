# SESP Ottawa 2050 — Electrical Load Disaggregation
## Carleton University Capstone, 2026

### Quick start
```bash
cd SESP_Ottawa_2050/
julia --project=. src/run_pipeline.jl          # full pipeline
julia --project=. src/ev_model.jl              # EV simulation only
julia --project=. src/fsa_weights.jl           # train FSA weights only
julia --project=. src/disaggregate_fsa.jl      # disaggregate existing workbook
```

---

### Folder structure

```
SESP_Ottawa_2050/
│
├── README.md                   ← this file
├── CLAUDE.md                   ← context doc for AI assistants
├── config.toml                 ← scenario parameters (single source of truth)
├── Project.toml                ← Julia package dependencies
│
├── data/                       ← INPUT DATA (checked into repo)
│   ├── FSA_Within_Ottawa_Weight.csv       ← GIS boundary weights (static)
│   ├── COP_Curve.csv                      ← Heat pump COP lookup table
│   ├── ottawa_oat_2023.csv                ← Observed hourly OAT for 2023
│   ├── ottawa_oat_2050_rcp45.csv          ← RCP4.5-adjusted hourly OAT
│   ├── real_load_2023.csv                 ← IESO observed Ottawa load (MW)
│   ├── real_load_2024.csv                 ← IESO observed 2024 (validation)
│   ├── commercial_scenarios/              ← Buildings team EnergyPlus outputs
│   │   ├── comm_2050_NG.csv
│   │   ├── comm_2050_NRG.csv
│   │   ├── comm_2050_CNG.csv
│   │   ├── comm_2050_CNRG.csv
│   │   └── comm_2050_CST.csv
│   └── ev_inputs/                         ← EV simulation inputs
│       ├── Average_Consumption_Per_Temperature.csv
│       ├── EV_Profiles.csv
│       ├── average_hourly_temperatures_ottawa_final.csv
│       └── percentile_distances.csv
│
├── ieso_cache/                 ← DOWNLOADED DATA (gitignored, auto-fetched)
│   ├── FSA_YYYYMM.zip          ← IESO hourly consumption by FSA
│   ├── Zonal_YYYY.csv           ← IESO zonal demand
│   └── weather_*.csv            ← ECCC weather cache
│
├── src/                        ← SOURCE CODE
│   ├── run_pipeline.jl          ← MAIN ENTRY POINT — calls everything in order
│   ├── common.jl                ← Shared utilities (download, parsing, config)
│   ├── ev_model.jl              ← EV fleet charging simulation (from EV_Dev_4.jl)
│   ├── residential.jl           ← Residential load model (extracted from Excel)
│   ├── commercial.jl            ← Commercial load loader (reads scenario CSVs)
│   ├── assemble_loads.jl        ← Total = Res + Comm + EV + Residual
│   ├── fsa_weights.jl           ← Train proportional weights (from FSA_Proportional.jl)
│   ├── disaggregate_fsa.jl      ← Apply weights to total load (from FSA_Disagg_FromXLSX.jl)
│   └── write_xlsx.jl            ← Generate the output Excel workbook
│
├── results/                    ← OUTPUT (gitignored)
│   ├── Load_Disaggregation_V10.xlsx   ← Full workbook
│   ├── fsa_loads_2050.csv             ← 8760 × 45 FSA load profiles (MW)
│   ├── analysis_summary.csv           ← Energy totals, peaks, shares
│   ├── fsa_premise_analysis.csv       ← Premise coverage comparison
│   └── weights_hour_month/            ← Weight CSVs per FSA
│
└── reference/                  ← ARCHIVED SCRIPTS (not part of pipeline)
    ├── FSA_Dissagregation_C03.jl      ← Prop + RF ML comparison
    ├── Load_Disaggregation_V9.xlsx    ← Previous workbook version
    └── notes/
```

---

### What each source file does

| File | Role | Inputs | Outputs |
|---|---|---|---|
| `run_pipeline.jl` | Orchestrator. Calls all modules in order. | `config.toml` | Everything in `results/` |
| `common.jl` | Shared: config loading, IESO download/parse, weather fetch, COP lookup | Various | DataFrames in memory |
| `ev_model.jl` | EV fleet simulation. Temperature-dependent charging across 8,760 hours. | `data/ev_inputs/`, weather | `ev_load_MW` vector (3 scenarios) |
| `residential.jl` | Residential heating/cooling/plug model. Currently in Excel — to be extracted. | OAT, COP_Curve, census params from config | `res_load_2023`, `res_load_2050` vectors |
| `commercial.jl` | Reads pre-computed commercial scenario CSVs from buildings team. | `data/commercial_scenarios/` | `comm_load_2050` (5 scenarios) |
| `assemble_loads.jl` | Assembles total: Res + Comm + EV + scaled residual. | Module outputs + `real_load_2023.csv` | `total_2050_MW` (active scenario) |
| `fsa_weights.jl` | Trains proportional weights from IESO data (2018-2023). | `ieso_cache/` | `weights_hour_month/` CSVs |
| `disaggregate_fsa.jl` | Applies HourMonth weights to total load. | Total load + weights + GIS CSV | `fsa_loads_2050.csv` |
| `write_xlsx.jl` | Generates the presentation-ready Excel workbook. | All above | `Load_Disaggregation_V10.xlsx` |

---

### Data files required to run

**Must be in repo (`data/`):**
- `FSA_Within_Ottawa_Weight.csv` — you already have this
- `COP_Curve.csv` — extract from Excel COP_Curve tab (17 rows × 9 cols)
- `ottawa_oat_2023.csv` — extract from Hourly_Load_Res col B (8,760 rows)
- `ottawa_oat_2050_rcp45.csv` — extract from Hourly_Load_Res col C
- `real_load_2023.csv` — extract from Total Loads col B
- `real_load_2024.csv` — extract from Total Loads col F
- Commercial scenario CSVs — extract from Commercial tab cols D–H
- EV input CSVs — already exist on your machine (4 files in VSCode_EVs/)

**Auto-downloaded (`ieso_cache/`):**
- IESO FSA ZIPs (2018–2025) — fetched by `fsa_weights.jl`
- IESO Zonal CSVs — fetched by `fsa_weights.jl`

---

### config.toml — scenario parameters

```toml
[census]
sf_dwellings_2021 = 286075
lr_dwellings_2021 = 43025
mh_dwellings_2021 = 76895
total_dwellings_2021 = 407250
dwelling_growth_rate = 0.015  # /yr
projection_year = 2050

[population]
pop_2016 = 934243
pop_2021 = 1017449

[electrification]
hp_penetration_2023 = 0.10
ac_penetration_2023 = 0.60
ac_penetration_2050 = 0.75

[scenarios]
# Active scenario selections (change these to switch)
active_ev = "Base"           # Low / Base / High
active_commercial = "CNG"   # NG / NRG / CNG / CNRG / CST
active_hp = "Base"           # Low / Base / High
active_plug = "Base"         # Low / Base / High
active_residual = "M3"      # M1 / M2 / M3

[hp_scenarios]
Low = 0.55
Base = 0.75
High = 0.92

[plug_scenarios]
Low = 1.20
Base = 1.46
High = 1.70

[residual_methods]
M1 = 1.75
M2_source = "dwelling_growth"
M3_source = "population_growth"

[heating_regression]
intercept = -155.7  # MW
slope = 86.3        # MW/HDH

[paths]
gis_csv = "data/FSA_Within_Ottawa_Weight.csv"
cop_csv = "data/COP_Curve.csv"
oat_2023 = "data/ottawa_oat_2023.csv"
oat_2050 = "data/ottawa_oat_2050_rcp45.csv"
real_load_2023 = "data/real_load_2023.csv"
ieso_cache = "ieso_cache"
results = "results"
```

---

### Migration status

| Component | Current location | Status | Migration needed |
|---|---|---|---|
| EV simulation | `EV_Dev_4.jl` (standalone) | Working | Fix hardcoded paths → config.toml |
| FSA weight training | `FSA_Proportional.jl` (standalone) | Working | Extract to `fsa_weights.jl` module |
| FSA disaggregation | `FSA_Disagg_FromXLSX.jl` (standalone) | Working | Extract to `disaggregate_fsa.jl` |
| Residential model | Excel formulas (Hourly_Load_Res) | Working | **Needs extraction to `residential.jl`** |
| Commercial load | Excel + pasted CSVs | Working | Trivial — just read the CSVs |
| Total assembly | Excel formulas (Total Loads + Residual_Hourly) | Working | Extract to `assemble_loads.jl` |
| COP lookup | Excel COP_Curve tab | Working | Extract to CSV + lookup function |
| Workbook generation | Manual | N/A | New: `write_xlsx.jl` |
| ML comparison | `FSA_Dissagregation_C03.jl` | Reference only | Move to `reference/` |

---

### Known limitations
See ReadMe tab in the Excel workbook for full list. Key ones:
- Residual is ~40–50% of total load (commercial base, industrial, transit not modelled)
- Single representative weather year (2023 aligned)
- Dwelling type mix held constant to 2050
- FSA weights from IESO smart meter data (partial spatial coverage)
- ML residual model (M4) has circular evaluation issue — do not use
