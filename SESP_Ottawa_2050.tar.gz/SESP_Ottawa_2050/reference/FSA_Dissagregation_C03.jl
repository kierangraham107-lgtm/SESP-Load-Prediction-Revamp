#!/usr/bin/env julia
#=
  IESO Ottawa FSA Load Disaggregation — Proportional + ML Comparison
  Multi-year training with weather features
  Deps: HTTP CSV DataFrames ZipFile Dates Printf DecisionTree Random URIs
=#

using HTTP, CSV, DataFrames, ZipFile, Dates, Printf, Statistics, Logging, Random, DecisionTree, URIs

# ── Config ──
const FSA_BASE   = "https://reports-public.ieso.ca/public/HourlyConsumptionByFSA"
const ZONAL_BASE = "https://reports-public.ieso.ca/public/DemandZonal"
const ECCC_BULK  = "https://climate.weather.gc.ca/climate_data/bulk_data_e.html"
const OTTAWA_CDA_STATION = 30578  # Ottawa CDA RCS

# FSA set and boundary corrections are loaded from the GIS weights CSV at runtime.
# Only FSAs with FSA_Within_Weight > 0 are included; weights >= 0.99 are treated as 1.0.
function load_fsa_weights(csv_path::String; threshold=0.99)
    df = CSV.read(csv_path, DataFrame; silencewarnings=true, stringtype=String)
    fsa_set     = Set{String}()
    corrections = Dict{String,Float64}()
    for row in eachrow(df)
        fsa = strip(string(row.CFSAUID))
        w   = ismissing(row.FSA_Within_Weight) ? 0.0 : Float64(row.FSA_Within_Weight)
        w == 0.0 && continue
        push!(fsa_set, fsa)
        w < threshold && (corrections[fsa] = w)
    end
    @info "Loaded $(length(fsa_set)) Ottawa FSAs; $(length(corrections)) with boundary correction < $threshold"
    return fsa_set, corrections
end

# ── Download Helper ──
function download_cached(url::String, path::String; timeout=120)
    if !isfile(path)
        @info "Downloading: $(basename(path))"
        resp = HTTP.get(url; readtimeout=timeout, connect_timeout=30)
        write(path, resp.body)
        @info "  ✓ $(round(filesize(path)/1e6, digits=1)) MB"
    end
    return path
end

# ══════════════════════════════════════════════════════════════
#  WEATHER DATA (adapted from Weather_Stripper.jl)
# ══════════════════════════════════════════════════════════════

function month_span(sd::Date, ed::Date)
    pairs = Tuple{Int,Int}[]
    y, m = year(sd), month(sd)
    while y < year(ed) || (y == year(ed) && m <= month(ed))
        push!(pairs, (y, m))
        m += 1
        if m == 13; m = 1; y += 1; end
    end
    return pairs
end

function fetch_weather(station_id::Int, start_date::Date, end_date::Date;
                       cache_dir="./ieso_cache")
    mkpath(cache_dir)
    cache_path = joinpath(cache_dir, "weather_$(station_id)_$(start_date)_$(end_date).csv")

    if isfile(cache_path)
        @info "Using cached weather: $(basename(cache_path))"
        df = CSV.read(cache_path, DataFrame; silencewarnings=true, stringtype=String)
        df.datetime = DateTime.(df.datetime)
        return df
    end

    @info "Fetching weather for station $station_id: $start_date to $end_date"
    frames = DataFrame[]

    for (y, m) in month_span(start_date, end_date)
        url = string(URI(ECCC_BULK; query=Dict(
            "format"=>"csv", "stationID"=>string(station_id),
            "timeframe"=>"1", "Year"=>string(y), "Month"=>string(m)
        )))
        try
            r = HTTP.get(url, ["User-Agent"=>"FSA-Disagg/1.0", "Accept"=>"text/csv"];
                         readtimeout=30, connect_timeout=15)
            r.status == 200 || continue

            df = CSV.read(IOBuffer(r.body), DataFrame;
                          header=true, skipto=2, normalizenames=true,
                          missingstring=["","M","NA"], silencewarnings=true, stringtype=String)

            isempty(df) && continue

            # Find datetime column
            dt_col = nothing
            for c in names(df)
                cl = lowercase(c)
                if contains(cl, "date") && contains(cl, "time") && contains(cl, "lst")
                    dt_col = c; break
                end
            end
            if dt_col === nothing
                for c in names(df)
                    if contains(lowercase(c), "date") && contains(lowercase(c), "time")
                        dt_col = c; break
                    end
                end
            end
            dt_col === nothing && continue

            # Find temp column
            temp_col = nothing
            for c in names(df)
                cl = lowercase(c)
                if contains(cl, "temp") && contains(cl, "°c") && !contains(cl, "dew") && !contains(cl, "flag")
                    temp_col = c; break
                end
            end
            if temp_col === nothing
                for c in names(df)
                    if contains(lowercase(c), "temp") && !contains(lowercase(c), "dew") && !contains(lowercase(c), "flag")
                        temp_col = c; break
                    end
                end
            end

            # Find humidity column
            hum_col = nothing
            for c in names(df)
                cl = lowercase(c)
                if contains(cl, "hum") && contains(cl, "%") && !contains(cl, "flag")
                    hum_col = c; break
                end
            end
            if hum_col === nothing
                for c in names(df)
                    if contains(lowercase(c), "hum") && !contains(lowercase(c), "flag")
                        hum_col = c; break
                    end
                end
            end

            # Find wind column
            wind_col = nothing
            for c in names(df)
                cl = lowercase(c)
                if contains(cl, "wind") && contains(cl, "spd") && !contains(cl, "flag")
                    wind_col = c; break
                end
            end

            # Parse datetime
            dt_vals = String.(df[!, dt_col])
            local datetimes
            for fmt in [dateformat"yyyy-mm-dd HH:MM", dateformat"yyyy-mm-dd HH:MM:SS"]
                try datetimes = DateTime.(strip.(dt_vals), fmt); break; catch; end
            end
            if !@isdefined(datetimes)
                try datetimes = DateTime.(strip.(dt_vals)); catch; continue; end
            end

            out = DataFrame(datetime=datetimes)
            if temp_col !== nothing
                out.temp_c = passmissing(Float64).(df[!, temp_col])
            end
            if hum_col !== nothing
                out.rel_hum = passmissing(Float64).(df[!, hum_col])
            end
            if wind_col !== nothing
                out.wind_spd = passmissing(Float64).(df[!, wind_col])
            end

            # Filter to date range
            out = filter(r -> start_date <= Date(r.datetime) <= end_date, out)
            !isempty(out) && push!(frames, out)

        catch e
            @warn "Weather fetch failed for $y-$m" exception=e
        end
        sleep(0.3)
    end

    if isempty(frames)
        @warn "No weather data retrieved"
        return DataFrame(datetime=DateTime[], temp_c=Float64[])
    end

    result = vcat(frames...; cols=:union)
    sort!(result, :datetime)
    result = unique(result, :datetime)

    # Fill missing temps with forward fill (carries last valid value forward)
    if :temp_c in Symbol.(names(result))
        last_valid = 0.0
        for i in 1:nrow(result)
            if !ismissing(result.temp_c[i])
                last_valid = result.temp_c[i]
            else
                result.temp_c[i] = last_valid
            end
        end
    end

    CSV.write(cache_path, result)
    @info "Weather: $(nrow(result)) hours cached"
    return result
end

# ══════════════════════════════════════════════════════════════
#  FSA DATA FETCHING
# ══════════════════════════════════════════════════════════════

function fetch_fsa_monthly(yr::Int, mo::Int; cache_dir="./ieso_cache")
    mkpath(cache_dir)
    ym = @sprintf("%04d%02d", yr, mo)
    zip_path = download_cached(
        "$(FSA_BASE)/PUB_HourlyConsumptionByFSA_$(ym)_v1.zip",
        joinpath(cache_dir, "FSA_$(ym).zip")
    )
    return parse_fsa_zip(zip_path)
end

function parse_fsa_zip(zip_path::String)
    reader = ZipFile.Reader(zip_path)
    csv_entries = filter(f -> endswith(lowercase(f.name), ".csv"), reader.files)
    isempty(csv_entries) && error("No CSV file found in ZIP: $zip_path")
    csv_entry = first(csv_entries)
    csv_bytes = read(csv_entry)
    close(reader)

    lines = split(String(csv_bytes), '\n')
    hdr_idx = findfirst(l -> !isempty(strip(l)) && !startswith(strip(l), "\\\\"), lines)
    hdr_fields = strip.(split(strip(String(lines[hdr_idx])), ','))

    # Detect long format
    is_long = any(h -> contains(lowercase(h), "fsa") || contains(lowercase(h), "consumption"), hdr_fields)
    if !is_long && hdr_idx+1 <= length(lines)
        v = strip(split(strip(String(lines[hdr_idx+1])), ',')[1])
        is_long = length(v)==3 && isletter(v[1]) && isdigit(v[2]) && isletter(v[3])
    end

    csv_str = join(lines[hdr_idx:end], '\n')
    df = CSV.read(IOBuffer(csv_str), DataFrame; missingstring=["","NA"], silencewarnings=true, stringtype=String)
    for c in names(df)
        if (startswith(string(c),"Column")||startswith(string(c),"Unnamed")) && all(ismissing,df[!,c])
            select!(df, Not(c))
        end
    end

    return is_long ? pivot_long(df) : parse_wide(df)
end

function pivot_long(df::DataFrame)
    cols = names(df)
    fsa_col = dt_col = hr_col = val_col = nothing

    for c in cols
        cl = lowercase(string(c))
        if fsa_col===nothing
            v=nothing; for x in df[!,c]; ismissing(x)&&continue; v=strip(string(x)); break; end
            if v!==nothing && length(v)==3 && isletter(v[1]) && isdigit(v[2]) && isletter(v[3])
                fsa_col=c; continue; end
            if contains(cl,"fsa"); fsa_col=c; continue; end
        end
        if hr_col===nothing && (contains(cl,"hour")||cl=="he")
            if eltype(df[!,c])<:Union{Missing,Number}; hr_col=c; continue; end; end
        if dt_col===nothing
            if eltype(df[!,c])<:Union{Missing,Date,DateTime}; dt_col=c; continue; end
            if contains(cl,"date"); dt_col=c; continue; end
            v=nothing; for x in df[!,c]; ismissing(x)&&continue; v=strip(string(x)); break; end
            if v!==nothing && occursin(r"^\d{4}-\d{2}-\d{2}",v); dt_col=c; continue; end
        end
        if val_col===nothing && c!=fsa_col && c!=dt_col && c!=hr_col && dt_col!==nothing
            if eltype(df[!,c])<:Union{Missing,Number}; val_col=c; end; end
    end

    dates = eltype(df[!,dt_col])<:Union{Missing,Date} ? Date.(df[!,dt_col]) :
            eltype(df[!,dt_col])<:Union{Missing,DateTime} ? Date.(df[!,dt_col]) :
            Date.(strip.(string.(df[!,dt_col])), dateformat"yyyy-mm-dd")
    df[!,:datetime] = DateTime.(dates) .+ Hour.(Int.(df[!,hr_col]) .- 1)

    wide = unstack(df, :datetime, fsa_col, val_col; combine=sum)
    for c in names(wide); c=="datetime"&&continue; wide[!,c]=coalesce.(wide[!,c],0.0); end
    sort!(wide,:datetime)
    return wide
end

function parse_wide(df::DataFrame)
    rename!(df, names(df)[1]=>:datetime)
    T=eltype(df.datetime)
    if T<:Union{Missing,DateTime}; df.datetime=DateTime.(df.datetime)
    elseif T<:Union{Missing,Date}; df.datetime=DateTime.(df.datetime)
    else
        vals=strip.(string.(df.datetime))
        for fmt in [dateformat"yyyy-mm-dd HH:MM:SS",dateformat"yyyy-mm-dd HH:MM"]
            try df.datetime=DateTime.(vals,fmt); break; catch; end; end
    end
    for c in names(df); c=="datetime"&&continue
        all(ismissing,df[!,c]) && (select!(df,Not(c)); continue)
        df[!,c]=coalesce.(Float64.(df[!,c]),0.0); end
    sort!(df,:datetime)
    return df
end

function fetch_fsa_range(y1,m1,y2,m2; cache_dir="./ieso_cache")
    dfs = DataFrame[]
    cur = Date(y1,m1,1)
    stop = Date(y2,m2,1)
    while cur <= stop
        try
            push!(dfs, fetch_fsa_monthly(year(cur),month(cur); cache_dir))
        catch e
            @warn "Failed FSA $(year(cur))-$(month(cur))" exception=e
        end
        cur += Month(1)
    end
    isempty(dfs) && error("No FSA data fetched")
    combined = vcat(dfs...; cols=:union)
    for c in names(combined); c=="datetime"&&continue; combined[!,c]=coalesce.(combined[!,c],0.0); end
    sort!(combined,:datetime)
    @info "FSA: $(nrow(combined)) rows, $(ncol(combined)-1) FSAs"
    return combined
end

# ── Zonal Demand ──
function fetch_zonal(yr::Int; cache_dir="./ieso_cache")
    mkpath(cache_dir)
    fname = yr < Dates.year(now()) ? "PUB_DemandZonal_$(yr).csv" : "PUB_DemandZonal.csv"
    path = download_cached("$(ZONAL_BASE)/$(fname)", joinpath(cache_dir,"Zonal_$(yr).csv"); timeout=60)
    lines = readlines(path)
    start = findfirst(l -> !startswith(strip(l),"\\\\") && !isempty(strip(l)), lines)
    df = CSV.read(IOBuffer(join(lines[start:end],'\n')), DataFrame; silencewarnings=true, stringtype=String)
    df.datetime = DateTime.(Date.(df.Date)) .+ Hour.(df.Hour .- 1)
    select!(df, :datetime, :Ottawa, Symbol("Ontario Demand")=>:ontario_demand)
    df = filter(r->Dates.year(r.datetime)==yr, df)
    @info "Zonal $yr: $(nrow(df)) rows"
    return df
end

function fetch_zonal_range(y1,y2; cache_dir="./ieso_cache")
    combined = vcat([fetch_zonal(y; cache_dir) for y in y1:y2]...)
    sort!(combined,:datetime)
    return combined
end

# ── Filter Ottawa ──
function filter_ottawa(df::DataFrame, ottawa_fsas::Set{String}; exclude_fsas=String[])
    excl = Set(uppercase.(exclude_fsas))
    fsa_cols = filter(c -> uppercase(c) in ottawa_fsas && !(uppercase(c) in excl),
                      filter(c -> c != "datetime", names(df)))
    @info "Ottawa FSAs: $(length(fsa_cols)) (excluded: $exclude_fsas)"
    return select(df, :datetime, fsa_cols...)
end

# ══════════════════════════════════════════════════════════════
#  PROPORTIONAL DISAGGREGATION
# ══════════════════════════════════════════════════════════════

# corrections: Dict{FSA => weight} for FSAs with weight < 0.99 (from load_fsa_weights).
# Weights are applied to raw load before computing shares, so shares naturally sum to 1.0.
function proportional_disaggregate(fsa_df::DataFrame, zonal::DataFrame,
                                    corrections::Dict{String,Float64}=Dict{String,Float64}())
    merged = innerjoin(fsa_df, zonal; on=:datetime)
    fsa_cols = filter(c -> c ∉ ["datetime","Ottawa","ontario_demand"], names(merged))
    for c in fsa_cols; merged[!,c] ./= 1000.0; end  # kW→MW

    # Apply boundary corrections before summing
    for c in fsa_cols
        w = get(corrections, uppercase(c), 1.0)
        w < 1.0 && (merged[!,c] .*= w)
    end

    corrected_total = vec(sum(Matrix(merged[!,fsa_cols]), dims=2))
    merged.fsa_raw_total_mw = corrected_total
    merged.coverage_ratio = corrected_total ./ merged.Ottawa

    rename!(merged, :Ottawa => :ottawa_zonal_mw)

    shares = Dict{String,Vector{Float64}}()
    for c in fsa_cols
        shares[c] = merged[!,c] ./ corrected_total
        shares[c] = replace(shares[c], NaN=>0.0, Inf=>0.0)
    end

    return merged, shares, fsa_cols
end

function compute_prop_weights(shares::Dict, fsa_cols::Vector{String})
    return Dict(c => mean(shares[c]) for c in fsa_cols)
end

# ══════════════════════════════════════════════════════════════
#  ML — Feature Engineering
# ══════════════════════════════════════════════════════════════

function build_features(dt::Vector{DateTime}, ottawa_load::Vector{<:Number};
                        weather::Union{DataFrame,Nothing}=nothing)
    n = length(dt)

    # Base features: 8 columns
    nf = weather !== nothing && :temp_c in Symbol.(names(weather)) ? 12 : 8
    X = Matrix{Float64}(undef, n, nf)

    for i in 1:n
        h = Dates.hour(dt[i])
        doy = Dates.dayofyear(dt[i])
        X[i,1] = Float64(h)                          # hour
        X[i,2] = Float64(Dates.dayofweek(dt[i]))     # dow
        X[i,3] = Float64(Dates.month(dt[i]))          # month
        X[i,4] = Float64(ottawa_load[i])              # total load
        X[i,5] = sin(2π * h / 24)                    # cyclic hour sin
        X[i,6] = cos(2π * h / 24)                    # cyclic hour cos
        X[i,7] = sin(2π * doy / 365)                 # cyclic season sin
        X[i,8] = cos(2π * doy / 365)                 # cyclic season cos
    end

    # Weather features if available
    if weather !== nothing && :temp_c in Symbol.(names(weather))
        # Build lookup: datetime -> row index in weather
        wx_lookup = Dict{DateTime,Int}()
        for (i,row) in enumerate(eachrow(weather))
            wx_lookup[row.datetime] = i
        end

        has_hum = :rel_hum in Symbol.(names(weather))
        has_wind = :wind_spd in Symbol.(names(weather))

        for i in 1:n
            idx = get(wx_lookup, dt[i], 0)
            if idx > 0
                t = ismissing(weather.temp_c[idx]) ? 0.0 : weather.temp_c[idx]
                X[i,9]  = t                                           # temperature
                X[i,10] = max(18.0 - t, 0.0)                         # heating degree (base 18)
                X[i,11] = max(t - 18.0, 0.0)                         # cooling degree (base 18)
                X[i,12] = has_hum && !ismissing(weather.rel_hum[idx]) ? Float64(weather.rel_hum[idx]) : 50.0
            else
                X[i,9]  = 0.0
                X[i,10] = 18.0
                X[i,11] = 0.0
                X[i,12] = 50.0
            end
        end
    end

    return X
end

# ══════════════════════════════════════════════════════════════
#  ML — Training and Prediction
# ══════════════════════════════════════════════════════════════

function train_ml_shares(merged::DataFrame, fsa_cols::Vector{String};
                          weather=nothing, n_trees=200, max_depth=15, min_samples=10)
    X = build_features(merged.datetime, merged.ottawa_zonal_mw; weather)
    models = Dict{String,Any}()

    @info "Training $(length(fsa_cols)) RF models ($(n_trees) trees, depth=$max_depth, $(size(X,2)) features, $(size(X,1)) samples)"

    for (i,c) in enumerate(fsa_cols)
        y = merged[!,c] ./ merged.ottawa_zonal_mw
        y = replace(y, NaN=>0.0, Inf=>0.0)
        y = Float64.(y)

        rf = build_forest(y, X,
            -1,           # n_subfeatures (-1 = sqrt)
            n_trees,
            0.7,          # partial_sampling
            max_depth,
            min_samples
        )
        models[c] = rf

        if i % 10 == 0 || i == length(fsa_cols)
            @info "  Trained $i/$(length(fsa_cols)) models"
        end
    end

    return models
end

function predict_ml_shares(models::Dict, dt::Vector{DateTime}, ottawa_load::Vector{<:Number},
                           fsa_cols::Vector{String}; weather=nothing)
    X = build_features(dt, ottawa_load; weather)
    predictions = Dict{String,Vector{Float64}}()

    for c in fsa_cols
        pred = apply_forest(models[c], X)
        predictions[c] = max.(pred, 0.0)
    end

    # Do NOT renormalize — model was trained on boundary-fraction-scaled shares
    # that sum to ~0.88, so forcing to 1.0 would inflate every FSA's share by ~14%

    return predictions
end

# ══════════════════════════════════════════════════════════════
#  EVALUATION
# ══════════════════════════════════════════════════════════════

function evaluate(actual::Dict, predicted::Dict, fsa_cols::Vector{String})
    metrics = DataFrame(FSA=String[], MAE=Float64[], RMSE=Float64[], MAPE=Float64[])
    for c in fsa_cols
        a, p = actual[c], predicted[c]
        mae = mean(abs.(a .- p))
        rmse = sqrt(mean((a .- p).^2))
        mask = a .> 0.001
        mape = sum(mask)>0 ? mean(abs.((a[mask].-p[mask])./a[mask]))*100 : NaN
        push!(metrics, (c, mae, rmse, mape))
    end
    sort!(metrics, :MAE)
    return metrics
end

# ── Printing ──
function print_weights(w::Dict, title::String)
    println("\n" * "="^70)
    println("  $title")
    println("="^70)
    sorted = sort(collect(w), by=x->x[2], rev=true)
    total = sum(v for (_,v) in sorted)
    println(@sprintf("  %-6s  %10s  %8s", "FSA", "Weight", "Share%"))
    println("  " * "-"^30)
    for (k,v) in sorted
        println(@sprintf("  %-6s  %10.6f  %7.2f%%", k, v, v/total*100))
    end
    println("  " * "-"^30)
    println(@sprintf("  %-6s  %10.6f  %7.2f%%", "TOTAL", total, 100.0))
    println("="^70)
end

function print_comparison(pm::DataFrame, mm::DataFrame)
    println("\n" * "="^75)
    println("  METHOD COMPARISON — Proportional vs ML (test data)")
    println("="^75)
    sort!(pm, :FSA); sort!(mm, :FSA)
    println(@sprintf("  %-6s  %10s  %10s  %10s  %10s  %6s", "FSA","Prop MAE","ML MAE","Prop RMSE","ML RMSE","Winner"))
    println("  " * "-"^65)

    prop_wins = 0; ml_wins = 0
    for i in 1:nrow(pm)
        fsa = pm.FSA[i]
        j = findfirst(mm.FSA .== fsa)
        j === nothing && continue
        winner = mm.MAE[j] < pm.MAE[i] ? "ML" : "Prop"
        winner == "ML" ? (ml_wins+=1) : (prop_wins+=1)
        println(@sprintf("  %-6s  %10.6f  %10.6f  %10.6f  %10.6f  %6s",
            fsa, pm.MAE[i], mm.MAE[j], pm.RMSE[i], mm.RMSE[j], winner))
    end

    println("  " * "-"^65)
    println(@sprintf("  %-6s  %10.6f  %10.6f  %10.6f  %10.6f",
        "AVG", mean(pm.MAE), mean(mm.MAE), mean(pm.RMSE), mean(mm.RMSE)))
    println("\n  ML wins: $ml_wins | Proportional wins: $prop_wins out of $(nrow(pm)) FSAs")
    mae_improve = (1 - mean(mm.MAE)/mean(pm.MAE)) * 100
    println(@sprintf("  Overall MAE improvement: %.1f%%", mae_improve))
    println("="^75)
end

# ══════════════════════════════════════════════════════════════
#  MAIN PIPELINE
# ══════════════════════════════════════════════════════════════

function run_full_pipeline(;
    train_years    = 2018:2023,
    val_year       = 2024,
    test_year      = 2025,
    test_end_month = 11,
    exclude_fsas   = String[],
    weights_csv    = "./FSA_Within_Ottawa_Weight.csv",
    cache_dir      = "./ieso_cache",
    output_dir     = "./results"
)
    mkpath(output_dir)

    println("="^75)
    println("  IESO Ottawa FSA Disaggregation — Full Pipeline")
    println("  Train: $(first(train_years))-$(last(train_years)) | Val: $val_year | Test: $test_year")
    println("  Excluded FSAs: $exclude_fsas")
    println("="^75)

    # ── 0. Load FSA weights ──
    ottawa_fsas, corrections = load_fsa_weights(weights_csv)
    println("\n  Boundary corrections applied to: $(sort(collect(keys(corrections))))")

    # ── 1. Fetch multi-year FSA training data ──
    println("\n▸ Step 1: Fetching FSA data $(first(train_years))-$(last(train_years))...")
    fsa_train_raw = fetch_fsa_range(first(train_years), 1, last(train_years), 12; cache_dir)
    fsa_train = filter_ottawa(fsa_train_raw, ottawa_fsas; exclude_fsas)
    zonal_train = fetch_zonal_range(first(train_years), last(train_years); cache_dir)

    # ── 2. Fetch weather data ──
    println("\n▸ Step 2: Fetching Ottawa weather data...")
    wx_start = Date(first(train_years), 1, 1)
    wx_end   = Dates.lastdayofmonth(Date(test_year, test_end_month, 1))
    weather = fetch_weather(OTTAWA_CDA_STATION, wx_start, wx_end; cache_dir)
    @info "Weather: $(nrow(weather)) hours, temp range $(minimum(skipmissing(weather.temp_c)))°C to $(maximum(skipmissing(weather.temp_c)))°C"

    # ── 3. Proportional disaggregation on training data ──
    println("\n▸ Step 3: Proportional disaggregation (training)...")
    train_merged, train_shares, fsa_cols = proportional_disaggregate(fsa_train, zonal_train, corrections)
    prop_weights = compute_prop_weights(train_shares, fsa_cols)
    print_weights(prop_weights, "PROPORTIONAL WEIGHTS ($(first(train_years))-$(last(train_years)) avg)")

    CSV.write(joinpath(output_dir, "proportional_weights.csv"),
        DataFrame(FSA=collect(keys(prop_weights)), Weight=collect(values(prop_weights))))

    # ── 4. Train ML on multi-year data ──
    println("\n▸ Step 4: Training Random Forest on $(nrow(train_merged)) hours with weather...")
    ml_models = train_ml_shares(train_merged, fsa_cols;
        weather, n_trees=200, max_depth=15, min_samples=10)

    # ML weights (average predicted shares on training data)
    train_ml_pred = predict_ml_shares(ml_models, train_merged.datetime,
                                       train_merged.ottawa_zonal_mw, fsa_cols; weather)
    ml_weights = Dict(c => mean(train_ml_pred[c]) for c in fsa_cols)
    print_weights(ml_weights, "ML WEIGHTS (Random Forest, $(first(train_years))-$(last(train_years)) avg)")

    CSV.write(joinpath(output_dir, "ml_weights.csv"),
        DataFrame(FSA=collect(keys(ml_weights)), Weight=collect(values(ml_weights))))

    # ── 5. Validate on val_year ──
    println("\n▸ Step 5: Validating on $val_year...")
    fsa_val_raw = fetch_fsa_range(val_year, 1, val_year, 12; cache_dir)
    fsa_val = filter_ottawa(fsa_val_raw, ottawa_fsas; exclude_fsas)
    zonal_val = fetch_zonal(val_year; cache_dir)
    val_merged, val_actual, _ = proportional_disaggregate(fsa_val, zonal_val, corrections)

    val_prop_pred = Dict(c => fill(prop_weights[c], nrow(val_merged)) for c in fsa_cols)
    val_ml_pred = predict_ml_shares(ml_models, val_merged.datetime,
                                     val_merged.ottawa_zonal_mw, fsa_cols; weather)

    val_prop_m = evaluate(val_actual, val_prop_pred, fsa_cols)
    val_ml_m = evaluate(val_actual, val_ml_pred, fsa_cols)
    println("\n  --- Validation ($val_year) ---")
    print_comparison(val_prop_m, val_ml_m)

    # ── 6. Test on test_year ──
    println("\n▸ Step 6: Testing on $test_year...")
    fsa_test_raw = fetch_fsa_range(test_year, 1, test_year, test_end_month; cache_dir)
    fsa_test = filter_ottawa(fsa_test_raw, ottawa_fsas; exclude_fsas)
    zonal_test = fetch_zonal(test_year; cache_dir)
    test_merged, test_actual, _ = proportional_disaggregate(fsa_test, zonal_test, corrections)

    test_prop_pred = Dict(c => fill(prop_weights[c], nrow(test_merged)) for c in fsa_cols)
    test_ml_pred = predict_ml_shares(ml_models, test_merged.datetime,
                                      test_merged.ottawa_zonal_mw, fsa_cols; weather)

    test_prop_m = evaluate(test_actual, test_prop_pred, fsa_cols)
    test_ml_m = evaluate(test_actual, test_ml_pred, fsa_cols)
    println("\n  --- Test ($test_year) ---")
    print_comparison(test_prop_m, test_ml_m)

    # ── 7. Save outputs ──
    println("\n▸ Step 7: Saving results...")

    test_prop_m[!, :Method] .= "Proportional"
    test_ml_m[!, :Method] .= "RandomForest"
    CSV.write(joinpath(output_dir, "comparison_$(test_year).csv"), vcat(test_prop_m, test_ml_m))

    # Save test predictions as MW
    for (name, preds) in [("proportional", test_prop_pred), ("ml", test_ml_pred)]
        out = DataFrame(datetime=test_merged.datetime, ottawa_zonal_mw=test_merged.ottawa_zonal_mw)
        for c in fsa_cols
            out[!,c] = preds[c] .* test_merged.ottawa_zonal_mw
        end
        CSV.write(joinpath(output_dir, "test_$(name)_$(test_year).csv"), out)
    end

    CSV.write(joinpath(output_dir, "train_disaggregated.csv"), train_merged)

    println("\n" * "="^75)
    println("  ✓ Pipeline complete. All outputs in: $(output_dir)/")
    println("="^75)

    return (prop_weights=prop_weights, ml_weights=ml_weights, ml_models=ml_models,
            val_prop=val_prop_m, val_ml=val_ml_m, test_prop=test_prop_m, test_ml=test_ml_m)
end

# ══════════════════════════════════════════════════════════════
#  RUN
# ══════════════════════════════════════════════════════════════

results = run_full_pipeline(
    train_years    = 2018:2023,   # 6 years of training data
    val_year       = 2024,        # validation
    test_year      = 2025,        # final test
    test_end_month = 11,
    exclude_fsas   = [""],
    cache_dir      = "./ieso_cache",
    output_dir     = "./results"
)