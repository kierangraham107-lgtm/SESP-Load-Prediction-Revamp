using CSV
using DataFrames
using Dates
using Random

# ** General parameter struct **********************************************************************************
struct EVSimConfig
    num_evs::Int               # Total number of EVs in the fleet
    workplace_pct::Float64     # % of EVs that charge at work 
    residential_std_hours::Float64  # Spread (std dev) of home charger start times
    weekend_std_hours::Float64      # Spread of weekend charging start times
    workplace_variability_hours::Int # hour window for workplace arrival times
    trips_per_person::Float64  # Average daily trips (scales distance)
    start_year::Int            # Year of simulation (for holiday/calendar logic)
    jan1_is_monday::Bool       # If true, overrides real day-of-week with a fixed calendar
    run_one_day::Bool          # If true, simulates only one specific day
    day_index::Int             # Which day to simulate (if run_one_day is true)
end


# ** HelperSSS ************************************************************************************************
#col_to_float Converts a DataFrame column to Float64, replacing missing values with NaN.

#fill_nan_linear! Fills any NaN gaps in a vector using linear interpolation. 
#Leading NaNs are forward-filled; trailing NaNs are backward-filled. This is used to patch missing temperature data.

#lininterp_extrap Builds a reusable interpolation function from two vectors x and y. Given a query value,
#it returns the linearly interpolated y value. This is used to look up energy consumption (kWh/km) at any temperature

col_to_float(v) = Float64.(coalesce.(v, NaN))

#Bug fix for missing values
function fill_nan_linear!(x::Vector{Float64})
    n = length(x)

    i = 1
    while i <= n && isnan(x[i])
        i += 1
    end
    if i == n + 1
        error("All values are missing/NaN.")
    end
    for k = 1:i-1
        x[k] = x[i]
    end

    while i <= n
        if !isnan(x[i])
            i += 1
            continue
        end
        j = i
        while j <= n && isnan(x[j])
            j += 1
        end
        if j == n + 1
            for k = i:n
                x[k] = x[i-1]
            end
            break
        end
        a = x[i-1]
        b = x[j]
        L = j - (i - 1)
        for k = i:j-1
            t = (k - (i - 1)) / L
            x[k] = a + t * (b - a)
        end
        i = j + 1
    end
    return x
end

# ** Load Profile Mechanics ******************************************************************************
function lininterp_extrap(x::Vector{Float64}, y::Vector{Float64})
    p = sortperm(x)
    xs = x[p]; ys = y[p]
    n = length(xs)
    return function (xq::Float64)
        if xq <= xs[1]
            t = (xq - xs[1]) / (xs[2] - xs[1])
            return ys[1] + t * (ys[2] - ys[1])
        elseif xq >= xs[n]
            t = (xq - xs[n-1]) / (xs[n] - xs[n-1])
            return ys[n-1] + t * (ys[n] - ys[n-1])
        else
            i = searchsortedlast(xs, xq)
            t = (xq - xs[i]) / (xs[i+1] - xs[i])
            return ys[i] + t * (ys[i+1] - ys[i])
        end
    end
end

# ** Load Profile Mechanics ***************************************************************************
# mod24 Simple modulo-24 helper for wrapping hour indices around a 24-hour clock.

# counts_from_offsets Takes a list of hour offsets (e.g., [-1, 0, 0, 2]) and bins them into a 24-element array counting how many EVs have each offset. 
# This creates a histogram of shifted start times.

# shift_sum The core convolution operation. It takes a base 24-hour load profile (e.g., "typical residential charging curve") and a count array of offsets,
# then produces a new 24-hour profile that's the sum of all time-shifted versions of the base profile. This is how charging diversity/spread is modelled 
# efficiently without looping over every individual EV like the previous years model.

# sample_offsets_normal Draws N random integer hour offsets from a normal distribution with the given standard deviation. Used for residential and 
# weekend chargers, whose start times vary naturally.

# sample_offsets_workplace Draws N random integer hour offsets uniformly from [-variability_hours, +variability_hours]. Workplace arrivals are more 
# predictable, so a uniform window is used instead of a bell curve.

@inline mod24(i::Int) = mod(i, 24)

function counts_from_offsets(offsets::Vector{Int})
    c = zeros(Int, 24)
    @inbounds for o in offsets
        c[mod24(o) + 1] += 1
    end
    return c
end

function shift_sum(base::Vector{Float64}, counts::Vector{Int})
    out = zeros(Float64, 24)
    @inbounds for shift = 0:23
        c = counts[shift + 1]
        if c != 0
            for h = 0:23
                out[h + 1] += c * base[mod24(h - shift) + 1]
            end
        end
    end
    return out
end

function sample_offsets_normal(N::Int, std_hours::Float64, rng::AbstractRNG)
    N <= 0 && return Int[]
    return round.(Int, std_hours .* randn(rng, N))
end

function sample_offsets_workplace(N::Int, variability_hours::Int, rng::AbstractRNG)
    N <= 0 && return Int[]
    variability_hours <= 0 && return zeros(Int, N)
    return rand(rng, -variability_hours:variability_hours, N)
end

# ** Calendar Logic *******************************************************************************
# holiday_set Returns a Set of Canadian statutory holiday dates for a given year (New Year's, Good Friday, Easter Monday, Victoria Day, Canada Day, 
# Labour Day, Thanksgiving, Christmas, Boxing Day).

#is_weekend_or_holiday Given a day-of-year number, checks whether it falls on a Saturday, Sunday, or statutory holiday. The jan1_is_monday flag 
#lets you override real calendar dates with a synthetic week cycle (useful for clean scenario analysis).

function holiday_set(year::Int)
    return Set((
        Date(year, 1, 1),
        Date(year, 3, 30),
        Date(year, 4, 2),
        Date(year, 5, 21),
        Date(year, 7, 1),
        Date(year, 9, 3),
        Date(year, 10, 8),
        Date(year, 12, 25),
        Date(year, 12, 26),
    ))
end

function is_weekend_or_holiday(day_of_year::Int, cfg::EVSimConfig, hset::Set{Date})
    d = Date(cfg.start_year, 1, 1) + Day(day_of_year - 1)
    is_h = d in hset
    if cfg.jan1_is_monday
        dow = mod(day_of_year - 1, 7) + 1
    else
        dow = dayofweek(d)
    end
    is_wknd = (dow == 6 || dow == 7)
    return is_wknd || is_h
end

# ** Main Simulation: simulate_ev_load_2050 ********************************************************************
# 1. Loads four CSV files: temperature-vs-consumption data, hourly charging profiles (residential/workplace/wedekend), hourly Ottawa temperatures, and a distance distribution by percentile.
# 2. Prepares data: interpolates missing temperatures, builds the consumption-at-temperature lookup function, and divides EVs into distance bins based on the percentile distribution.
# 3. Loops over each day in the simulation range:
    # Checks if it's a weekend/holiday.
    # For each distance bin of EVs:
    # Calculates daily km driven (`distance × trips_per_person`).
    # On weekends/holidays: applies the weekend charging profile with normally-distributed time offsets.
    # On weekdays: splits EVs into residential and workplace fractions, applies their respective profiles and offset distributions, then sums them.
    # For each hour, looks up the temperature → gets kWh/km → multiplies by km/day → scales by the profile weight to get hourly load in kWh.
# 4. Returns the total load array in MW (divides kWh by 1000).

function simulate_ev_load(
    cfg::EVSimConfig;
    path_consumption::String = "C:/Users/Kieran Graham/OneDrive - Carleton University/Capstone/VSCode_SESP_KG/VSCode_EVs/Average_Consumption_Per_Temperature.csv",
    path_profiles::String    = "C:/Users/Kieran Graham/OneDrive - Carleton University/Capstone/VSCode_SESP_KG/VSCode_EVs/EV Profiles.csv",
    path_temps::String       = "C:/Users/Kieran Graham/OneDrive - Carleton University/Capstone/VSCode_SESP_KG/VSCode_EVs/average_hourly_temperatures_ottawa_final.csv",
    path_dist::String        = "C:/Users/Kieran Graham/OneDrive - Carleton University/Capstone/VSCode_SESP_KG/VSCode_EVs/percentile_distances.csv",
    rng::AbstractRNG         = MersenneTwister(1),
)
    cons_df = CSV.read(path_consumption, DataFrame; normalizenames=true)
    prof_df = CSV.read(path_profiles, DataFrame; normalizenames=true)
    temp_df = CSV.read(path_temps, DataFrame; normalizenames=true)
    dist_df = CSV.read(path_dist, DataFrame; normalizenames=true)

    dropmissing!(cons_df, [:Temperature, :Consumption])
    dropmissing!(dist_df, [:Distance_km, :Percentage])

    temps = col_to_float(temp_df.temperature)
    fill_nan_linear!(temps)

    n_hours = length(temps)
    if n_hours % 24 != 0
        error("Temperature series length must be a multiple of 24. Got $n_hours.")
    end
    n_days = n_hours ÷ 24

    day_range = if cfg.run_one_day
        (cfg.day_index < 1 || cfg.day_index > n_days) && error("day_index must be 1..$n_days, got $(cfg.day_index).")
        cfg.day_index:cfg.day_index
    else
        1:n_days
    end

    out_hours = cfg.run_one_day ? 24 : n_hours
    load_kW = zeros(Float64, out_hours)

    base_res = col_to_float(prof_df.Residential); base_res[isnan.(base_res)] .= 0.0
    base_wkp = col_to_float(prof_df.Workplace);   base_wkp[isnan.(base_wkp)] .= 0.0
    base_wnd = col_to_float(prof_df.Weekend);     base_wnd[isnan.(base_wnd)] .= 0.0

    xT = Float64.(cons_df.Temperature)
    yC = Float64.(cons_df.Consumption)
    consumption_at_T = lininterp_extrap(xT, yC)

    distances = Float64.(dist_df.Distance_km)
    percents = Float64.(dist_df.Percentage) ./ 100.0
    bin_evs = round.(Int, cfg.num_evs .* percents)

    frac_wkp = clamp(cfg.workplace_pct / 100.0, 0.0, 1.0)
    frac_res = 1.0 - frac_wkp

    hset = holiday_set(cfg.start_year)

    out_day = 0
    for day in day_range
        out_day += 1
        is_wend = is_weekend_or_holiday(day, cfg, hset)
        day_load_kWh = zeros(Float64, 24)

        for b in eachindex(bin_evs)
            Nbin = bin_evs[b]
            Nbin <= 0 && continue

            km_per_day = distances[b] * cfg.trips_per_person

            p = if is_wend
                offs = sample_offsets_normal(Nbin, cfg.weekend_std_hours, rng)
                shift_sum(base_wnd, counts_from_offsets(offs))
            else
                Nres = round(Int, Nbin * frac_res)
                Nwkp = Nbin - Nres

                offs_res = sample_offsets_normal(Nres, cfg.residential_std_hours, rng)
                p_res = shift_sum(base_res, counts_from_offsets(offs_res))

                offs_wkp = sample_offsets_workplace(Nwkp, cfg.workplace_variability_hours, rng)
                p_wkp = shift_sum(base_wkp, counts_from_offsets(offs_wkp))

                p_res .+ p_wkp
            end

            for h = 1:24
                T = temps[(day - 1) * 24 + h]
                kWh_per_km = consumption_at_T(T)
                day_load_kWh[h] += p[h] * (kWh_per_km * km_per_day)
            end
        end

        if cfg.run_one_day
            load_kW .= day_load_kWh
        else
            idx = (day - 1) * 24
            load_kW[idx + 1:idx + 24] .= day_load_kWh
        end
    end

    return load_kW ./ 1000.0
end

# *** Execution *************************************************************************************************
# write_ev_load_csv Writes the resulting MW load vector to a CSV with columns `hour_of_year` and `ev_load_MW`.
# Bottom of file The simulation is configured and run:
# Output is saved to `ev_load_2050_MW.csv`.

function write_ev_load_csv(load_MW::Vector{Float64}, out_path::String)
    df = DataFrame(hour_of_year = collect(1:length(load_MW)), ev_load_MW = load_MW)
    CSV.write(out_path, df)
    return out_path
end

cfg = EVSimConfig(
    56_000,
    15.0,
    2.0,
    2.5,
    2,
    2.67,
    2025,
    false,
    false,
    1
)

load_MW = simulate_ev_load(cfg)
write_ev_load_csv(load_MW, "ev_load_2025_MW.csv")
#println("Peak (MW) = ", maximum(load_MW))
#println("Sum (TWh) = ", sum(load_MW)/1000000)