#!/usr/bin/env julia
#=
  FSA Load Disaggregation from Load_Disaggregation_V9.xlsx
  ─────────────────────────────────────────────────────────
  1. Reads the `Residual_Hourly` tab, takes the "Active Total" column,
     applies per-hour × per-month FSA weights from results_prop/weights_hour_month/,
     and appends "FSA_Disaggregated" to the workbook.

  2. Reads PREMISE_COUNT (time-varying) from the cached IESO FSA ZIP files,
     compares against Polygon_Count (GIS total premises) from the weights CSV,
     and appends "FSA_Premise_Analysis" to the workbook.

  Deps: XLSX CSV DataFrames ZipFile Dates Printf Statistics
=#

using XLSX, CSV, DataFrames, ZipFile, Dates, Printf, Statistics

# ══════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════

const XLSX_PATH         = "./Load_Disaggregation_V9.xlsx"
const SOURCE_SHEET      = "Residual_Hourly"
const OUTPUT_SHEET      = "FSA_Disaggregated"
const PREMISE_SHEET     = "FSA_Premise_Analysis"
const WEIGHTS_DIR       = "./results_prop/weights_hour_month"
const GIS_WEIGHTS_CSV   = "./FSA_Within_Ottawa_Weight.csv"
const CACHE_DIR         = "./ieso_cache"

# ══════════════════════════════════════════════════════════════
#  LOAD DISAGGREGATION WEIGHTS
# ══════════════════════════════════════════════════════════════

function load_all_weights(dir::String)
    weights = Dict{String, Matrix{Float64}}()
    csv_files = filter(f -> endswith(lowercase(f), ".csv"), readdir(dir; join=true))
    isempty(csv_files) && error("No CSV weight files found in: $dir")
    for path in csv_files
        fsa = uppercase(splitext(basename(path))[1])
        df = CSV.read(path, DataFrame; silencewarnings=true)
        mat = zeros(Float64, 24, 12)
        for row in eachrow(df)
            h = Int(row.Hour)
            for m in 1:12
                col = Symbol("M$m")
                if hasproperty(row, col)
                    mat[h+1, m] = Float64(row[col])
                end
            end
        end
        weights[fsa] = mat
    end
    @info "Loaded weights for $(length(weights)) FSAs"
    return weights
end

# ══════════════════════════════════════════════════════════════
#  LOAD GIS POLYGON COUNTS  (static, from FSA_Within_Ottawa_Weight.csv)
# ══════════════════════════════════════════════════════════════

"""
Returns Dict{FSA => Int} of total GIS premise counts per FSA.
Only includes FSAs with Polygon_Count > 0.
"""
function load_polygon_counts(csv_path::String)
    df = CSV.read(csv_path, DataFrame; silencewarnings=true, stringtype=String)
    counts = Dict{String, Int}()
    for row in eachrow(df)
        fsa = strip(string(row.CFSAUID))
        pc  = ismissing(row.Polygon_Count) ? 0 : Int(row.Polygon_Count)
        pc > 0 && (counts[fsa] = pc)
    end
    @info "Loaded GIS Polygon_Count for $(length(counts)) FSAs"
    return counts
end

# ══════════════════════════════════════════════════════════════
#  EXTRACT PREMISE COUNTS FROM CACHED IESO ZIP FILES
# ══════════════════════════════════════════════════════════════

"""
Parse one FSA ZIP and extract (datetime, fsa, premise_count) rows.
Returns nothing if no premise count column is found (wide-format files).
"""
function parse_premise_zip(zip_path::String)
    reader = ZipFile.Reader(zip_path)
    csv_entries = filter(f -> endswith(lowercase(f.name), ".csv"), reader.files)
    isempty(csv_entries) && (close(reader); return nothing)

    csv_bytes = read(first(csv_entries))
    close(reader)

    lines = split(String(csv_bytes), '\n')
    hdr_idx = findfirst(l -> !isempty(strip(l)) && !startswith(strip(l), "\\\\"), lines)
    hdr_idx === nothing && return nothing

    csv_str = join(lines[hdr_idx:end], '\n')
    df = CSV.read(IOBuffer(csv_str), DataFrame;
                  missingstring=["", "NA"], silencewarnings=true, stringtype=String)

    # Drop empty unnamed columns
    for c in names(df)
        if (startswith(string(c), "Column") || startswith(string(c), "Unnamed")) &&
           all(ismissing, df[!, c])
            select!(df, Not(c))
        end
    end

    cols = names(df)

    # Detect required columns
    fsa_col = dt_col = hr_col = val_col = pc_col = nothing
    for c in cols
        cl = lowercase(string(c))
        # FSA column: first column whose values look like FSA codes (e.g. K1A)
        if fsa_col === nothing
            v = nothing
            for x in df[!, c]; ismissing(x) && continue; v = strip(string(x)); break; end
            if v !== nothing && length(v) == 3 && isletter(v[1]) && isdigit(v[2]) && isletter(v[3])
                fsa_col = c; continue
            end
            contains(cl, "fsa") && (fsa_col = c; continue)
        end
        hr_col  === nothing && (contains(cl, "hour") || cl == "he") &&
            eltype(df[!, c]) <: Union{Missing, Number} && (hr_col = c; continue)
        if dt_col === nothing
            eltype(df[!, c]) <: Union{Missing, Date, DateTime} && (dt_col = c; continue)
            contains(cl, "date") && (dt_col = c; continue)
            v = nothing
            for x in df[!, c]; ismissing(x) && continue; v = strip(string(x)); break; end
            v !== nothing && occursin(r"^\d{4}-\d{2}-\d{2}", v) && (dt_col = c; continue)
        end
        # Premise count column
        if pc_col === nothing && (contains(cl, "premise") || (contains(cl, "count") && !contains(cl, "polygon")))
            eltype(df[!, c]) <: Union{Missing, Number} && (pc_col = c; continue)
        end
        # Consumption value column (long format only)
        if val_col === nothing && c != fsa_col && c != dt_col && c != hr_col &&
           dt_col !== nothing && eltype(df[!, c]) <: Union{Missing, Number}
            val_col = c
        end
    end

    # Need at minimum: FSA, date, hour, premise count — otherwise this is a wide-format file
    (fsa_col === nothing || dt_col === nothing || hr_col === nothing || pc_col === nothing) &&
        return nothing

    # Parse datetimes
    raw_dates = eltype(df[!, dt_col]) <: Union{Missing, Date} ? Date.(df[!, dt_col]) :
                eltype(df[!, dt_col]) <: Union{Missing, DateTime} ? Date.(df[!, dt_col]) :
                Date.(strip.(string.(df[!, dt_col])), dateformat"yyyy-mm-dd")
    datetimes = DateTime.(raw_dates) .+ Hour.(Int.(df[!, hr_col]) .- 1)

    out = DataFrame(
        datetime      = datetimes,
        fsa           = uppercase.(strip.(string.(df[!, fsa_col]))),
        premise_count = coalesce.(Float64.(df[!, pc_col]), NaN),
    )
    filter!(r -> !isnan(r.premise_count) && r.premise_count > 0, out)
    return out
end

"""
Load PREMISE_COUNT from all cached ZIP files whose year-month falls within
the date range [start_date, end_date].
Returns a DataFrame: [year_month::String, fsa, reported_premises (median over month)]
"""
function extract_premise_counts(cache_dir::String, start_date::Date, end_date::Date,
                                 ottawa_fsas::Set{String})
    zip_files = filter(f -> endswith(f, ".zip") && startswith(basename(f), "FSA_"),
                       readdir(cache_dir; join=true))

    frames = DataFrame[]
    for path in zip_files
        # Parse year-month from filename e.g. FSA_202301.zip
        m = match(r"FSA_(\d{4})(\d{2})\.zip$", basename(path))
        m === nothing && continue
        yr, mo = parse(Int, m[1]), parse(Int, m[2])
        d = Date(yr, mo, 1)
        (d < start_date || d > end_date) && continue

        df = parse_premise_zip(path)
        df === nothing && continue
        isempty(df) && continue

        # Filter to Ottawa FSAs only
        filter!(r -> r.fsa in ottawa_fsas, df)
        isempty(df) && continue

        df[!, :year_month] .= @sprintf("%04d-%02d", yr, mo)
        push!(frames, df)
    end

    isempty(frames) && return nothing

    raw = vcat(frames...)

    # Aggregate: median reported premises per FSA per month
    # (premise count rarely changes within a month; median is robust to outliers)
    agg = combine(groupby(raw, [:year_month, :fsa]),
                  :premise_count => (x -> round(Int, median(x))) => :reported_premises)
    sort!(agg, [:year_month, :fsa])
    @info "Extracted premise counts: $(nrow(agg)) FSA×month records"
    return agg
end

# ══════════════════════════════════════════════════════════════
#  BUILD PREMISE ANALYSIS TABLE
# ══════════════════════════════════════════════════════════════

"""
Combine reported premise counts (time-varying) with GIS polygon counts (static).
Output columns: year_month, fsa, reported_premises, gis_total, coverage_pct
Coverage % = reported / gis_total × 100 (how much of the FSA's total premises are
being metered/reported in the IESO data).
"""
function build_premise_analysis(premise_df::DataFrame,
                                 polygon_counts::Dict{String, Int},
                                 fsa_list::Vector{String})
    rows = NamedTuple[]
    for row in eachrow(premise_df)
        fsa = row.fsa
        fsa in fsa_list || continue
        gis = get(polygon_counts, fsa, 0)
        cov = gis > 0 ? round(row.reported_premises / gis * 100, digits=2) : missing
        push!(rows, (
            year_month        = row.year_month,
            fsa               = fsa,
            reported_premises = row.reported_premises,
            gis_total         = gis,
            coverage_pct      = cov,
        ))
    end
    isempty(rows) && return nothing
    return DataFrame(rows)
end

# ══════════════════════════════════════════════════════════════
#  READ SOURCE SHEET
# ══════════════════════════════════════════════════════════════

function read_source_sheet(xlsx_path::String, sheet_name::String)
    @info "Reading sheet '$sheet_name' from $xlsx_path"
    xf = XLSX.readxlsx(xlsx_path)
    sheet_names = XLSX.sheetnames(xf)
    @info "Available sheets: $sheet_names"
    sheet_name in sheet_names || error("Sheet '$sheet_name' not found. Available: $sheet_names")

    sh   = xf[sheet_name]
    data = XLSX.getdata(sh)
    headers = [string(x) for x in data[1, :]]

    df = DataFrame()
    for (j, h) in enumerate(headers)
        df[!, h] = data[2:end, j]
    end
    @info "Source sheet: $(nrow(df)) rows, columns: $(names(df))"
    return df
end

# ══════════════════════════════════════════════════════════════
#  DETECT COLUMNS
# ══════════════════════════════════════════════════════════════

function detect_columns(df::DataFrame)
    cols = names(df)
    dt_col = nothing
    for c in cols
        cl = lowercase(c)
        any(x -> contains(cl, x), ["datetime", "date/time", "timestamp", "date"]) &&
            (dt_col = c; break)
    end
    at_col = nothing
    for c in cols
        cl = lowercase(c)
        contains(cl, "active") && contains(cl, "total") && (at_col = c; break)
    end
    if at_col === nothing
        for c in cols; contains(lowercase(c), "total") && (at_col = c; break); end
    end
    dt_col === nothing && error("Could not detect datetime column. Columns: $cols")
    at_col === nothing && error("Could not detect 'Active Total' column. Columns: $cols")
    @info "Datetime column    : '$dt_col'"
    @info "Active Total column: '$at_col'"
    return dt_col, at_col
end

# ══════════════════════════════════════════════════════════════
#  PARSE DATETIME
# ══════════════════════════════════════════════════════════════

function to_datetime(v)::Union{DateTime, Nothing}
    v === nothing && return nothing
    ismissing(v)  && return nothing
    v isa DateTime && return v
    v isa Date     && return DateTime(v)
    if v isa Number
        epoch = DateTime(1899, 12, 30)
        days_int = floor(Int, Float64(v))
        frac = Float64(v) - days_int
        return epoch + Day(days_int) + Millisecond(round(Int, frac * 86_400_000))
    end
    s = strip(string(v))
    isempty(s) && return nothing
    for fmt in [dateformat"yyyy-mm-dd HH:MM:SS", dateformat"yyyy-mm-dd HH:MM",
                dateformat"yyyy-mm-dd", dateformat"mm/dd/yyyy HH:MM:SS",
                dateformat"mm/dd/yyyy HH:MM", dateformat"mm/dd/yyyy",
                dateformat"d/m/yyyy H:MM", dateformat"d/m/yyyy"]
        try return DateTime(s, fmt); catch; end
    end
    @warn "Cannot parse datetime: '$s'"
    return nothing
end

# ══════════════════════════════════════════════════════════════
#  DISAGGREGATE
# ══════════════════════════════════════════════════════════════

function disaggregate(df::DataFrame, dt_col::String, at_col::String,
                       weights::Dict{String, Matrix{Float64}})
    fsa_list = sort(collect(keys(weights)))
    n = nrow(df)
    datetimes  = Vector{Union{DateTime,Missing}}(missing, n)
    load_vals  = Vector{Float64}(undef, n)
    valid_mask = falses(n)

    for i in 1:n
        dt = to_datetime(df[i, dt_col])
        dt === nothing && continue
        raw = df[i, at_col]
        (raw === nothing || ismissing(raw)) && continue
        load = Float64(raw)
        isnan(load) && continue
        datetimes[i]  = dt
        load_vals[i]  = load
        valid_mask[i] = true
    end

    n_valid = sum(valid_mask)
    @info "Valid rows: $n_valid / $n"
    n_valid == 0 && error("No valid rows — check datetime and Active Total columns")

    out = DataFrame(datetime=Vector{DateTime}(undef, n_valid),
                    active_total=Vector{Float64}(undef, n_valid))
    for fsa in fsa_list; out[!, fsa] = Vector{Float64}(undef, n_valid); end

    idx = 0
    for i in 1:n
        valid_mask[i] || continue
        idx += 1
        dt, load = datetimes[i], load_vals[i]
        h, mo = Dates.hour(dt), Dates.month(dt)
        out.datetime[idx]     = dt
        out.active_total[idx] = load
        for fsa in fsa_list
            out[idx, fsa] = weights[fsa][h+1, mo] * load
        end
    end
    return out
end

# ══════════════════════════════════════════════════════════════
#  WRITE SHEET
# ══════════════════════════════════════════════════════════════

function write_sheet(xlsx_path::String, sheet_name::String, out_df::DataFrame)
    @info "Writing sheet '$sheet_name' ($(nrow(out_df)) rows × $(ncol(out_df)) cols)"
    XLSX.openxlsx(xlsx_path, mode="rw") do xf
        existing = XLSX.sheetnames(xf)
        if sheet_name in existing
            @info "Sheet '$sheet_name' exists — reusing and overwriting cells"
            sh = xf[sheet_name]
        else
            XLSX.addsheet!(xf, sheet_name)
            sh = xf[sheet_name]
        end
        col_names = names(out_df)
        for (j, c) in enumerate(col_names); sh[1, j] = c; end
        for i in 1:nrow(out_df), (j, c) in enumerate(col_names)
            v = out_df[i, c]
            sh[i+1, j] = v isa DateTime ? string(v) : v
        end
    end
    @info "  ✓ Done"
end

# ══════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════

function main()
    println("="^70)
    println("  FSA Load Disaggregation + Premise Analysis — XLSX mode")
    println("  Source : $XLSX_PATH  →  sheet: $SOURCE_SHEET")
    println("  Weights: $WEIGHTS_DIR")
    println("="^70)

    # ── 1. Load disaggregation weights ──
    weights  = load_all_weights(WEIGHTS_DIR)
    fsa_list = sort(collect(keys(weights)))

    # ── 2. Read source sheet ──
    df = read_source_sheet(XLSX_PATH, SOURCE_SHEET)
    dt_col, at_col = detect_columns(df)

    # ── 3. Disaggregate ──
    println("\n▸ Disaggregating $(nrow(df)) rows across $(length(fsa_list)) FSAs...")
    out = disaggregate(df, dt_col, at_col, weights)

    println("\nSample (first 3 rows):")
    show(first(out, 3); allcols=false)
    println()

    write_sheet(XLSX_PATH, OUTPUT_SHEET, out)

    # ── 4. Premise count analysis ──
    println("\n▸ Building premise count analysis...")

    # Date range from the disaggregated data
    start_date = Date(minimum(out.datetime))
    end_date   = Date(maximum(out.datetime))
    @info "Date range: $start_date → $end_date"

    polygon_counts = load_polygon_counts(GIS_WEIGHTS_CSV)
    ottawa_fsas    = Set(fsa_list)

    premise_raw = extract_premise_counts(CACHE_DIR, start_date, end_date, ottawa_fsas)

    if premise_raw === nothing
        @warn """
        No PREMISE_COUNT data found in $CACHE_DIR for the date range $(start_date)–$(end_date).
        The IESO FSA files in that range may be wide-format (consumption only, no premise column).
        The '$PREMISE_SHEET' sheet will NOT be written.
        """
    else
        analysis = build_premise_analysis(premise_raw, polygon_counts, fsa_list)

        if analysis === nothing || nrow(analysis) == 0
            @warn "Premise analysis is empty — sheet will not be written."
        else
            # Print a quick summary per FSA (average coverage)
            println("\n  FSA Premise Coverage Summary (avg across months):")
            println(@sprintf("  %-6s  %10s  %10s  %10s", "FSA", "Reported", "GIS Total", "Coverage%"))
            println("  " * "-"^42)
            for gdf in groupby(analysis, :fsa)
                fsa = gdf.fsa[1]
                avg_rep = round(Int, mean(gdf.reported_premises))
                gis     = get(polygon_counts, fsa, 0)
                avg_cov = gis > 0 ? mean(skipmissing(gdf.coverage_pct)) : NaN
                println(@sprintf("  %-6s  %10d  %10d  %9.1f%%", fsa, avg_rep, gis, avg_cov))
            end
            println()

            write_sheet(XLSX_PATH, PREMISE_SHEET, analysis)
            println("  Columns: year_month | fsa | reported_premises | gis_total | coverage_pct")
        end
    end

    println("\n✓ Complete. Open '$XLSX_PATH' for results.")
    println("  Sheet '$OUTPUT_SHEET'  — hourly disaggregated load per FSA (MW)")
    println("  Sheet '$PREMISE_SHEET' — monthly reported vs GIS premises per FSA")
end

main()
