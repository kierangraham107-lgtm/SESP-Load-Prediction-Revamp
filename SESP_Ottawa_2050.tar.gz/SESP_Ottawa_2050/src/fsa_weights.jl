#!/usr/bin/env julia
#=
  IESO Ottawa FSA Load Disaggregation — Proportional Only
  Compares four levels of temporal granularity:
    1. Flat      — one weight per FSA (grand mean)
    2. ByHour    — 24 weights per FSA (captures daily shape)
    3. ByMonth   — 12 weights per FSA (captures seasonality)
    4. HourMonth — 24×12 = 288 weights per FSA (full granularity)
  No boundary corrections. No ML.
  Deps: HTTP CSV DataFrames ZipFile Dates Printf Statistics URIs
=#

using HTTP, CSV, DataFrames, ZipFile, Dates, Printf, Statistics, Logging, URIs

# ══════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════

const FSA_BASE   = "https://reports-public.ieso.ca/public/HourlyConsumptionByFSA"
const ZONAL_BASE = "https://reports-public.ieso.ca/public/DemandZonal"

# Load FSA set and boundary weights from the GIS CSV.
# Returns (Set of FSA codes, Dict{FSA => correction_factor}).
# Only FSAs with FSA_Within_Weight > 0 are included.
# Weights >= 0.99 are treated as 1.0 (no meaningful boundary clipping).
function load_fsa_weights(csv_path::String; threshold=0.99)
    df = CSV.read(csv_path, DataFrame; silencewarnings=true, stringtype=String)
    fsa_set     = Set{String}()
    corrections = Dict{String,Float64}()
    for row in eachrow(df)
        fsa = strip(string(row.CFSAUID))
        w   = ismissing(row.FSA_Within_Weight) ? 0.0 : Float64(row.FSA_Within_Weight)
        w == 0.0 && continue
        push!(fsa_set, fsa)
        w < threshold && (corrections[fsa] = w)
    end
    @info "Loaded $(length(fsa_set)) Ottawa FSAs; $(length(corrections)) with boundary correction < $threshold"
    return fsa_set, corrections
end

# ══════════════════════════════════════════════════════════════
#  DATA FETCHING  (cached to disk)
# ══════════════════════════════════════════════════════════════

function download_cached(url::String, path::String; timeout=120)
    if !isfile(path)
        @info "Downloading: $(basename(path))"
        resp = HTTP.get(url; readtimeout=timeout, connect_timeout=30)
        write(path, resp.body)
        @info "  ✓ $(round(filesize(path)/1e6, digits=1)) MB"
    end
    return path
end

function parse_fsa_zip(zip_path::String)
    reader = ZipFile.Reader(zip_path)
    csv_entries = filter(f -> endswith(lowercase(f.name), ".csv"), reader.files)
    isempty(csv_entries) && error("No CSV file found in ZIP: $zip_path")
    csv_bytes = read(first(csv_entries))
    close(reader)

    lines = split(String(csv_bytes), '\n')
    hdr_idx = findfirst(l -> !isempty(strip(l)) && !startswith(strip(l), "\\\\"), lines)
    hdr_fields = strip.(split(strip(String(lines[hdr_idx])), ','))

    is_long = any(h -> contains(lowercase(h), "fsa") || contains(lowercase(h), "consumption"), hdr_fields)
    if !is_long && hdr_idx+1 <= length(lines)
        v = strip(split(strip(String(lines[hdr_idx+1])), ',')[1])
        is_long = length(v)==3 && isletter(v[1]) && isdigit(v[2]) && isletter(v[3])
    end

    csv_str = join(lines[hdr_idx:end], '\n')
    df = CSV.read(IOBuffer(csv_str), DataFrame; missingstring=["","NA"],
                  silencewarnings=true, stringtype=String)
    for c in names(df)
        if (startswith(string(c),"Column")||startswith(string(c),"Unnamed")) && all(ismissing,df[!,c])
            select!(df, Not(c))
        end
    end
    return is_long ? _pivot_long(df) : _parse_wide(df)
end

function _pivot_long(df::DataFrame)
    cols = names(df)
    fsa_col = dt_col = hr_col = val_col = nothing
    for c in cols
        cl = lowercase(string(c))
        if fsa_col===nothing
            v=nothing; for x in df[!,c]; ismissing(x)&&continue; v=strip(string(x)); break; end
            if v!==nothing && length(v)==3 && isletter(v[1]) && isdigit(v[2]) && isletter(v[3])
                fsa_col=c; continue; end
            if contains(cl,"fsa"); fsa_col=c; continue; end
        end
        if hr_col===nothing && (contains(cl,"hour")||cl=="he")
            if eltype(df[!,c])<:Union{Missing,Number}; hr_col=c; continue; end; end
        if dt_col===nothing
            if eltype(df[!,c])<:Union{Missing,Date,DateTime}; dt_col=c; continue; end
            if contains(cl,"date"); dt_col=c; continue; end
            v=nothing; for x in df[!,c]; ismissing(x)&&continue; v=strip(string(x)); break; end
            if v!==nothing && occursin(r"^\d{4}-\d{2}-\d{2}",v); dt_col=c; continue; end
        end
        if val_col===nothing && c!=fsa_col && c!=dt_col && c!=hr_col && dt_col!==nothing
            if eltype(df[!,c])<:Union{Missing,Number}; val_col=c; end; end
    end
    dates = eltype(df[!,dt_col])<:Union{Missing,Date} ? Date.(df[!,dt_col]) :
            eltype(df[!,dt_col])<:Union{Missing,DateTime} ? Date.(df[!,dt_col]) :
            Date.(strip.(string.(df[!,dt_col])), dateformat"yyyy-mm-dd")
    df[!,:datetime] = DateTime.(dates) .+ Hour.(Int.(df[!,hr_col]) .- 1)
    wide = unstack(df, :datetime, fsa_col, val_col; combine=sum)
    for c in names(wide); c=="datetime"&&continue; wide[!,c]=coalesce.(wide[!,c],0.0); end
    sort!(wide,:datetime)
    return wide
end

function _parse_wide(df::DataFrame)
    rename!(df, names(df)[1]=>:datetime)
    T=eltype(df.datetime)
    if T<:Union{Missing,DateTime}; df.datetime=DateTime.(df.datetime)
    elseif T<:Union{Missing,Date}; df.datetime=DateTime.(df.datetime)
    else
        vals=strip.(string.(df.datetime))
        for fmt in [dateformat"yyyy-mm-dd HH:MM:SS",dateformat"yyyy-mm-dd HH:MM"]
            try df.datetime=DateTime.(vals,fmt); break; catch; end
        end
    end
    for c in names(df); c=="datetime"&&continue
        all(ismissing,df[!,c]) && (select!(df,Not(c)); continue)
        df[!,c]=coalesce.(Float64.(df[!,c]),0.0); end
    sort!(df,:datetime)
    return df
end

function fetch_fsa_range(y1, m1, y2, m2; cache_dir="./ieso_cache")
    mkpath(cache_dir)
    dfs = DataFrame[]
    cur = Date(y1,m1,1)
    stop = Date(y2,m2,1)
    while cur <= stop
        yr, mo = year(cur), month(cur)
        ym = @sprintf("%04d%02d", yr, mo)
        zip_path = download_cached(
            "$(FSA_BASE)/PUB_HourlyConsumptionByFSA_$(ym)_v1.zip",
            joinpath(cache_dir, "FSA_$(ym).zip")
        )
        try push!(dfs, parse_fsa_zip(zip_path))
        catch e; @warn "Failed FSA $yr-$mo" exception=e; end
        cur += Month(1)
    end
    isempty(dfs) && error("No FSA data fetched")
    combined = vcat(dfs...; cols=:union)
    for c in names(combined); c=="datetime"&&continue
        combined[!,c] = coalesce.(combined[!,c], 0.0); end
    sort!(combined, :datetime)
    @info "FSA: $(nrow(combined)) rows, $(ncol(combined)-1) FSAs"
    return combined
end

function fetch_zonal(yr::Int; cache_dir="./ieso_cache")
    mkpath(cache_dir)
    fname = yr < Dates.year(now()) ? "PUB_DemandZonal_$(yr).csv" : "PUB_DemandZonal.csv"
    path = download_cached("$(ZONAL_BASE)/$(fname)", joinpath(cache_dir,"Zonal_$(yr).csv"); timeout=60)
    lines = readlines(path)
    start = findfirst(l -> !startswith(strip(l),"\\\\") && !isempty(strip(l)), lines)
    df = CSV.read(IOBuffer(join(lines[start:end],'\n')), DataFrame; silencewarnings=true, stringtype=String)
    df.datetime = DateTime.(Date.(df.Date)) .+ Hour.(df.Hour .- 1)
    select!(df, :datetime, :Ottawa, Symbol("Ontario Demand")=>:ontario_demand)
    filter!(r -> Dates.year(r.datetime)==yr, df)
    @info "Zonal $yr: $(nrow(df)) rows"
    return df
end

function fetch_zonal_range(y1, y2; cache_dir="./ieso_cache")
    sort!(vcat([fetch_zonal(y; cache_dir) for y in y1:y2]...), :datetime)
end

function filter_ottawa(df::DataFrame, ottawa_fsas::Set{String}; exclude_fsas=String[])
    excl = Set(uppercase.(exclude_fsas))
    fsa_cols = filter(c -> uppercase(c) in ottawa_fsas && !(uppercase(c) in excl),
                      filter(c -> c != "datetime", names(df)))
    return select(df, :datetime, fsa_cols...)
end

# ══════════════════════════════════════════════════════════════
#  PROPORTIONAL DISAGGREGATION
# ══════════════════════════════════════════════════════════════

# Apply boundary corrections to raw FSA load before computing shares.
# corrections: Dict{FSA => weight} for FSAs with weight < 0.99 only.
# Shares naturally sum to 1.0 because the corrected totals are the denominator.
function disaggregate(fsa_df::DataFrame, zonal::DataFrame,
                      corrections::Dict{String,Float64}=Dict{String,Float64}())
    merged = innerjoin(fsa_df, zonal; on=:datetime)
    fsa_cols = filter(c -> c ∉ ["datetime","Ottawa","ontario_demand"], names(merged))
    for c in fsa_cols; merged[!,c] ./= 1000.0; end  # kW → MW

    # Apply boundary corrections to raw load before summing
    for c in fsa_cols
        w = get(corrections, uppercase(c), 1.0)
        w < 1.0 && (merged[!,c] .*= w)
    end

    corrected_total = vec(sum(Matrix(merged[!,fsa_cols]), dims=2))

    shares = Dict{String,Vector{Float64}}()
    for c in fsa_cols
        s = merged[!,c] ./ corrected_total
        shares[c] = replace(s, NaN=>0.0, Inf=>0.0)
    end

    rename!(merged, :Ottawa => :ottawa_zonal_mw)
    return merged, shares, fsa_cols
end

# ══════════════════════════════════════════════════════════════
#  WEIGHT COMPUTATION  (four levels of temporal granularity)
# ══════════════════════════════════════════════════════════════

# Each weight struct holds the lookup table for one granularity level.
# At prediction time: look up weight by key, multiply by ottawa_zonal_mw.

# 1. Flat — Dict{FSA, Float64}
function weights_flat(shares::Dict, fsa_cols)
    return Dict(c => mean(shares[c]) for c in fsa_cols)
end

# 2. ByHour — Dict{FSA, Vector{Float64}(24)}  indexed by hour 0..23
function weights_by_hour(shares::Dict, fsa_cols, datetimes)
    hours = Dates.hour.(datetimes)
    return Dict(c => [mean(shares[c][hours .== h]) for h in 0:23] for c in fsa_cols)
end

# 3. ByMonth — Dict{FSA, Vector{Float64}(12)}  indexed by month 1..12
function weights_by_month(shares::Dict, fsa_cols, datetimes)
    months = Dates.month.(datetimes)
    return Dict(c => [mean(shares[c][months .== m]) for m in 1:12] for c in fsa_cols)
end

# 4. HourMonth — Dict{FSA, Matrix{Float64}(24,12)}  [hour+1, month]
function weights_hour_month(shares::Dict, fsa_cols, datetimes)
    hours  = Dates.hour.(datetimes)
    months = Dates.month.(datetimes)
    out = Dict{String, Matrix{Float64}}()
    for c in fsa_cols
        w = zeros(24, 12)
        for h in 0:23, m in 1:12
            mask = (hours .== h) .& (months .== m)
            w[h+1, m] = sum(mask) > 0 ? mean(shares[c][mask]) : 0.0
        end
        out[c] = w
    end
    return out
end

# ══════════════════════════════════════════════════════════════
#  PREDICTION
# ══════════════════════════════════════════════════════════════

function predict_flat(weights, fsa_cols, datetimes)
    n = length(datetimes)
    return Dict(c => fill(weights[c], n) for c in fsa_cols)
end

function predict_by_hour(weights, fsa_cols, datetimes)
    hours = Dates.hour.(datetimes)
    return Dict(c => [weights[c][h+1] for h in hours] for c in fsa_cols)
end

function predict_by_month(weights, fsa_cols, datetimes)
    months = Dates.month.(datetimes)
    return Dict(c => [weights[c][m] for m in months] for c in fsa_cols)
end

function predict_hour_month(weights, fsa_cols, datetimes)
    hours  = Dates.hour.(datetimes)
    months = Dates.month.(datetimes)
    return Dict(c => [weights[c][hours[i]+1, months[i]] for i in eachindex(datetimes)] for c in fsa_cols)
end

# ══════════════════════════════════════════════════════════════
#  EVALUATION
# ══════════════════════════════════════════════════════════════

function evaluate(actual::Dict, predicted::Dict, fsa_cols)
    rows = NamedTuple[]
    for c in fsa_cols
        a, p = actual[c], predicted[c]
        mae  = mean(abs.(a .- p))
        rmse = sqrt(mean((a .- p).^2))
        mask = a .> 0.001
        mape = sum(mask) > 0 ? mean(abs.((a[mask] .- p[mask]) ./ a[mask])) * 100 : NaN
        push!(rows, (FSA=c, MAE=mae, RMSE=rmse, MAPE=mape))
    end
    return sort!(DataFrame(rows), :MAE)
end

function print_comparison(results::Dict{String,DataFrame}, fsa_cols)
    methods = collect(keys(results))
    ref = sort!(copy(results[first(methods)]), :FSA)
    fsa_list = ref.FSA

    println("\n" * "="^90)
    println("  WEIGHT GRANULARITY COMPARISON — mean MAE across $(length(fsa_list)) FSAs")
    println("="^90)
    header = @sprintf("  %-8s", "Method")
    for stat in ["Avg MAE", "Avg RMSE", "Avg MAPE%"]
        header *= @sprintf("  %12s", stat)
    end
    println(header)
    println("  " * "-"^60)
    for name in ["Flat","ByHour","ByMonth","HourMonth"]
        haskey(results, name) || continue
        df = results[name]
        println(@sprintf("  %-8s  %12.6f  %12.6f  %12.2f",
            name, mean(df.MAE), mean(df.RMSE), mean(skipmissing(df.MAPE))))
    end
    println("="^90)

    # Per-FSA breakdown for the best vs Flat
    best = argmin(Dict(n => mean(results[n].MAE) for n in keys(results) if n != "Flat"))
    println("\n  Per-FSA: Flat vs best ($best)")
    println(@sprintf("  %-6s  %10s  %10s  %8s", "FSA","Flat MAE","$(best) MAE","Δ%"))
    println("  " * "-"^42)
    flat_df = sort!(copy(results["Flat"]), :FSA)
    best_df = sort!(copy(results[best]), :FSA)
    for i in 1:nrow(flat_df)
        delta = (best_df.MAE[i] - flat_df.MAE[i]) / flat_df.MAE[i] * 100
        marker = delta < -5 ? " ◀" : ""
        println(@sprintf("  %-6s  %10.6f  %10.6f  %+7.1f%%%s",
            flat_df.FSA[i], flat_df.MAE[i], best_df.MAE[i], delta, marker))
    end
    println("="^90)
end

# ══════════════════════════════════════════════════════════════
#  MAIN PIPELINE
# ══════════════════════════════════════════════════════════════

function run_proportional(;
    train_years    = 2018:2023,
    val_year       = 2024,
    test_year      = 2025,
    test_end_month = 11,
    exclude_fsas   = String[],
    weights_csv    = "./FSA_Within_Ottawa_Weight.csv",
    cache_dir      = "./ieso_cache",
    output_dir     = "./results_prop"
)
    mkpath(output_dir)
    println("="^70)
    println("  Ottawa FSA Proportional Disaggregation")
    println("  Train: $(first(train_years))–$(last(train_years)) | Test: $test_year")
    println("="^70)

    # ── 0. Load FSA weights ──
    ottawa_fsas, corrections = load_fsa_weights(weights_csv)
    println("\n  Boundary corrections applied to: $(sort(collect(keys(corrections))))")

    # ── 1. Fetch data ──
    println("\n▸ Step 1: Fetching FSA + zonal data...")
    fsa_raw   = fetch_fsa_range(first(train_years), 1, last(train_years), 12; cache_dir)
    fsa_train = filter_ottawa(fsa_raw, ottawa_fsas; exclude_fsas)
    zonal_train = fetch_zonal_range(first(train_years), last(train_years); cache_dir)

    # ── 2. Compute shares from training data ──
    println("\n▸ Step 2: Computing proportional shares...")
    train_merged, train_shares, fsa_cols = disaggregate(fsa_train, zonal_train, corrections)
    @info "Training on $(nrow(train_merged)) hours, $(length(fsa_cols)) FSAs"

    # ── 3. Build all four weight tables ──
    println("\n▸ Step 3: Building weight tables...")
    wt_flat       = weights_flat(train_shares, fsa_cols)
    wt_hour       = weights_by_hour(train_shares, fsa_cols, train_merged.datetime)
    wt_month      = weights_by_month(train_shares, fsa_cols, train_merged.datetime)
    wt_hourmonth  = weights_hour_month(train_shares, fsa_cols, train_merged.datetime)

    # Save the flat weights for reference
    CSV.write(joinpath(output_dir, "weights_flat.csv"),
        sort!(DataFrame(FSA=collect(keys(wt_flat)), Weight=collect(values(wt_flat))), :FSA))

    # Save the hour×month weight table (one row per hour, one col per month, one file per FSA)
    hm_dir = joinpath(output_dir, "weights_hour_month")
    mkpath(hm_dir)
    for c in fsa_cols
        df = DataFrame(hcat(0:23, wt_hourmonth[c]), vcat(["Hour"], string.("M", 1:12)))
        CSV.write(joinpath(hm_dir, "$(c).csv"), df)
    end
    @info "Hour×month weight tables saved to $(hm_dir)/"

    # ── 4. Evaluate on test year ──
    println("\n▸ Step 4: Evaluating on test year ($test_year)...")
    fsa_test_raw = fetch_fsa_range(test_year, 1, test_year, test_end_month; cache_dir)
    fsa_test     = filter_ottawa(fsa_test_raw, ottawa_fsas; exclude_fsas)
    zonal_test   = fetch_zonal(test_year; cache_dir)
    test_merged, test_actual, _ = disaggregate(fsa_test, zonal_test, corrections)

    dt = test_merged.datetime
    preds = Dict(
        "Flat"      => predict_flat(wt_flat, fsa_cols, dt),
        "ByHour"    => predict_by_hour(wt_hour, fsa_cols, dt),
        "ByMonth"   => predict_by_month(wt_month, fsa_cols, dt),
        "HourMonth" => predict_hour_month(wt_hourmonth, fsa_cols, dt),
    )

    results = Dict(name => evaluate(test_actual, pred, fsa_cols) for (name, pred) in preds)
    print_comparison(results, fsa_cols)

    # ── 5. Save comparison CSV ──
    for (name, df) in results
        df[!, :Method] .= name
    end
    combined = vcat(values(results)...)
    CSV.write(joinpath(output_dir, "comparison_granularity_$(test_year).csv"), combined)

    # Save test predictions as MW (using HourMonth as the primary output)
    out = DataFrame(datetime=dt, ottawa_zonal_mw=test_merged.ottawa_zonal_mw)
    for c in fsa_cols
        out[!,c] = preds["HourMonth"][c] .* test_merged.ottawa_zonal_mw
    end
    CSV.write(joinpath(output_dir, "test_proportional_$(test_year).csv"), out)

    println("\n✓ Done. Outputs in: $(output_dir)/")
    return results
end

# ══════════════════════════════════════════════════════════════
#  RUN
# ══════════════════════════════════════════════════════════════

results = run_proportional(
    train_years    = 2018:2023,
    val_year       = 2024,
    test_year      = 2025,
    test_end_month = 11,
    cache_dir      = "./ieso_cache",
    output_dir     = "./results_prop"
)
