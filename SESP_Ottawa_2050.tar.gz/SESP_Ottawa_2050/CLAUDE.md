# SESP Load Prediction — Project Context

## What this project does
Disaggregates hourly Ottawa zonal electricity load (from IESO) down to individual
Forward Sortation Areas (FSAs — first 3 characters of a postal code) using
proportional weighting trained on 2018–2023 historical FSA consumption data.

The end goal is to apply those FSA-level disaggregated loads to a future-scenario
Excel workbook (`Load_Disaggregation_V10.xlsx`) so that 2050 projections can be
broken out by neighbourhood.

---

## Key files

| File | Purpose |
|---|---|
| `FSA_Proportional.jl` | Trains all four weight granularities (Flat / ByHour / ByMonth / HourMonth) from IESO data, evaluates on 2025 test year, saves weight CSVs to `results_prop/` |
| `FSA_Dissagregation_C03.jl` | Full pipeline: proportional + Random Forest ML comparison with weather features |
| `FSA_Disagg_FromXLSX.jl` | **Main script for xlsx workflow** — reads `Load_Disaggregation_V10.xlsx`, applies HourMonth weights, writes two new sheets back into the workbook |
| `FSA_Within_Ottawa_Weight.csv` | GIS boundary file: one row per FSA, key columns `CFSAUID`, `FSA_Within_Weight` (fraction of FSA inside Ottawa boundary), `Polygon_Count` (total GIS premises) |
| `Load_Disaggregation_V10.xlsx` | Input/output workbook. Source data is in the `Residual_Hourly` sheet. Contains 13 sheets with full model pipeline. |

---

## Data sources
- **FSA hourly consumption**: IESO public reports (`HourlyConsumptionByFSA`), cached as ZIP files in `ieso_cache/FSA_YYYYMM.zip`
- **Ottawa zonal demand**: IESO `DemandZonal`, cached as `ieso_cache/Zonal_YYYY.csv`
- **GIS boundary weights**: `FSA_Within_Ottawa_Weight.csv` (pre-computed, already in repo)

---

## Weight files
`results_prop/weights_hour_month/{FSA}.csv` — one file per FSA (e.g. `K1A.csv`).

Format: 24 rows (hours 0–23) × 13 columns (`Hour`, `M1`…`M12`).
Each cell is the mean share of Ottawa zonal load that FSA consumed during that
hour-of-day × month combination, computed over 2018–2023 training data.

Usage: `disaggregated_load[fsa] = weight[hour+1, month] × active_total`

---

## Load_Disaggregation_V10.xlsx — sheet structure

| Sheet | Tab colour | Purpose |
|---|---|---|
| ReadMe | Navy | Overview, usage guide, tab descriptions, data sources, known limitations, V10 changelog |
| Control_Panel | Navy | Central parameter hub. Scenario selectors in rows 59–64 (yellow highlighted, blue values). Only edit column B. |
| COP_Curve | Blue | Heat pump COP lookup by OAT bin. Anchored to NRCan/CanmetENERGY field study. |
| EV | Blue | 8,760-row hourly EV charging profiles: 2023 base + 2050 Low/Base/High from EV_Dev_4.jl |
| Commercial | Blue | 8,760-row hourly commercial load: 2023 base + 5 retrofit scenarios from buildings team |
| Hourly_Load_Res | Green | Residential load calculation: heating, cooling, plug loads from weather + census + COP |
| Total Loads | Green | Assembly: Real 2023 + Predicted 2023/2050 + Residual. Includes 2024 validation. |
| Residual_Hourly | Green | Projects 2023 residual to 2050 via 3 methods (M1/M2/M3). Col I = Active Total 2050. |
| Total Breakdown | Orange | Hour-by-hour 2050 decomposition: residential, commercial, EV, residual, total |
| Analysis | Orange | Summary statistics: annual energy (TWh), peak power (MW), scenario selections |
| FSA_Disaggregated | Purple | **Primary FSA output.** HourMonth weights × Active Total. 45 FSAs, weights sum to 1.0. |
| Flat_FSA_Disaggregation | Purple | Reference baseline. Flat weights × Active Total. 42 FSAs. Formula-linked to Residual_Hourly. |
| FSA_Premise_Analysis | Purple | Monthly IESO premises vs GIS polygon counts, with boundary-weight correction. |

---

## FSA_Disagg_FromXLSX.jl — what it does
1. Loads all `weights_hour_month` CSVs into `Dict{FSA => 24×12 Matrix}`
2. Reads `Residual_Hourly` sheet from `Load_Disaggregation_V10.xlsx`
3. Auto-detects the datetime column and the `Active Total 2050 (MW)` column
4. For every row: looks up `weight[hour+1, month]` per FSA, multiplies by Active Total
5. Writes sheet **`FSA_Disaggregated`**: `datetime | active_total | K0A | K0G | K1A | …` (MW per FSA)
6. Reads `PREMISE_COUNT` from the cached IESO ZIPs, `Polygon_Count` and `FSA_Within_Weight` from the GIS CSV
7. Writes sheet **`FSA_Premise_Analysis`** with boundary-corrected columns:
   `year_month | fsa | reported_premises | boundary_weight | adjusted_premises | gis_total | adjusted_coverage_pct | raw_coverage_pct`

### Premise coverage correction (V10)
IESO reports premise counts for all meters in an FSA regardless of municipal boundary.
For FSAs straddling Ottawa (e.g. K0A = 37% inside, K0G = 4% inside), the raw premise
count overstates Ottawa-specific coverage. V10 multiplies IESO reported premises by
`FSA_Within_Weight` before comparing to GIS polygon counts. Raw coverage is retained
for reference.

---

## Ottawa FSAs in scope
45 FSAs with `FSA_Within_Weight > 0`. A few have boundary corrections (weight < 0.99)
applied before computing shares so that partial-boundary FSAs don't inflate totals.
FSAs outside Ottawa (e.g. J9A — Quebec side) are excluded automatically.

Key boundary FSAs: K0A (37.2%), K0G (3.6%), K4K (0.08%), K7S (100%), K4B (100%), K4A (100%)

---

## Julia packages used
`HTTP`, `CSV`, `DataFrames`, `ZipFile`, `Dates`, `Printf`, `Statistics`,
`XLSX`, `DecisionTree`, `URIs`, `Logging`, `Random`

---

## Future work ideas
- **Dwelling-count-scaled weights**: normalise proportional weights by IESO premise count
  to get per-dwelling intensity, then scale by actual GIS dwelling count per FSA. Would
  account for FSAs with growing/different housing stock.
- **Census building-split per FSA**: run the residential heating/cooling model independently
  per FSA using FSA-level SF/LR/MH ratios from Statistics Canada census data, rather than
  applying city-wide averages.
- **ML residual model (M4)**: retrain on residual-only series (currently has circular
  evaluation issue — trained on total load). Not recommended until fixed.

---

## Current branch
`Proportional` — work in progress. `main` is the base branch for PRs.
